# learn-LaravelXFlutter
Repository pembelajaran membuat aplikasi mobile flutter dengan backend laravel
