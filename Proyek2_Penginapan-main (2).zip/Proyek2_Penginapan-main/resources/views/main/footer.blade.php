   <!--================ start footer Area  =================-->
   <footer class="footer-area section_gap">
    <div class="container">
        <div class="row">
            <div class="col-lg-6  col-md-12 col-sm-12">
                <div class="single-footer-widget">
                    <h6 class="footer_title">About Agency</h6>
                    <p>Kami adalah Penginapan Sederhana yang berlokasikan di Kota Batulicin Kalimantan. Berdiri sejak 2019. </p>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12">
                <div class="single-footer-widget">
                    <h6 class="footer_title">Navigation Links</h6>
                    <div class="row">
                        <div class="col-6">
                            <ul class="list_style">
                                <li><a href="/">Berita</a></li>
                                <li><a href="/about">About Us</a></li>
                                <li><a href="/galeri">Info Vaksin</a></li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list_style">

                                <li><a href="/kontak">Contact</a></li>
                                <li><a href="/masuk">Login</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="border_line"></div>
        <div class="row footer-bottom d-flex justify-content-between align-items-center">
            <p class="col-lg-8 col-sm-12 footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This website is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a target="_blank">Kelompok 7</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
            <div class="col-lg-4 col-sm-12 footer-social">
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>

            </div>
        </div>
    </div>
</footer>
<!--================ End footer Area  =================-->


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="{{ asset('js/jquery-3.2.1.min.js') }}"></script>
<script src="{{ asset('js/popper.js') }}"></script>
<script src="{{ asset('js/bootstrap.min.js') }}"></script>
<script src="{{ asset('vendors/owl-carousel/owl.carousel.min.js') }}"></script>
<script src="{{ asset('js/jquery.ajaxchimp.min.js') }}"></script>
<script src="{{ asset('js/mail-script.js') }}"></script>
<script src="{{ asset('vendors/bootstrap-datepicker/bootstrap-datetimepicker.min.js') }}"></script>
<script src="{{ asset('vendors/nice-select/js/jquery.nice-select.js') }}"></script>
<script src="{{ asset('js/mail-script.js') }}"></script>
<script src="{{ asset('js/stellar.js') }}"></script>
<script src="{{ asset('vendors/lightbox/simpleLightbox.min.js') }}"></script>
<script src="{{ asset('js/custom.js') }}"></script>
</body>
</html>
