<span class="invalid-feedback">
  <strong>{{ $message }}</strong>
</span>