<footer class="main-footer">
  <div class="footer-left">
    Copyright <script>document.write(new Date().getFullYear());</script> All rights reserved | This website is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a target="_blank">Kelompok 7</a>
  </div>
  <div class="footer-right">
    1.0
  </div>
</footer>